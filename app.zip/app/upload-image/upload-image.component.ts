import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { ImagepostService } from '../services/imagepost.service';
import { first } from 'rxjs/operators';

@Component({
  selector: 'app-upload-image',
  templateUrl: './upload-image.component.html',
  styleUrls: ['./upload-image.component.css']
})
export class UploadImageComponent implements OnInit {

  imageUploadForm: FormGroup;
  loading = false;
  submitted = false;
  returnUrl: string;
  imgURL:any;
  selectedFile:File;

  constructor(
      private formBuilder: FormBuilder,
      private imageService: ImagepostService
  ) {

  }

  ngOnInit() {
      this.imageUploadForm = this.formBuilder.group({
        title: ['', Validators.required],
        desc: ['', Validators.required],
        image:['']
    });
  }

  onFileChanged(files) {
    if (files.length === 0)
    return;

  this.selectedFile = files[0];

  var reader = new FileReader();
  reader.readAsDataURL(files[0]); 
  reader.onload = (_event) => { 
    this.imgURL = reader.result; 
  //   this.imageUploadForm.patchValue({
  //     image: {'image': reader.result, 'name': files[0].name}
  //  });
  
  }
    // const file = event.target.files[0];
    // this.f.image.patchValue(file);
  }

  get f() { return this.imageUploadForm.controls; }

  onSubmit() {
  this.submitted = true;

  // stop here if form is invalid
  if (this.imageUploadForm.invalid) {
      return;
  }

  this.loading = true;
  console.log(this.selectedFile);
  let fd = new FormData();
  Object.keys(this.imageUploadForm.value).map(key => fd.append(key, this.imageUploadForm.value[key]))
  fd.append('image', this.selectedFile);

  this.imageService.imagePost(fd)
            .pipe(first())
            .subscribe(
                data => {
                    console.log('image uplaoded successfull ', data);
                    this.loading = false;
                },
                error => {
                  console.log('Something went wrong! ', error);
                    this.loading = false;
                });
  }

}
