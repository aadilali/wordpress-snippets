import { Routes, RouterModule } from '@angular/router';
import { UploadImageComponent } from './upload-image/upload-image.component';
import { ListingComponent } from './listing/listing.component';


const appRoutes: Routes = [
    { path: 'upload-image', component: UploadImageComponent },
    { path: 'list', component: ListingComponent },

    // otherwise redirect to home
    { path: '**', redirectTo: '' }
];

export const routing = RouterModule.forRoot(appRoutes);
