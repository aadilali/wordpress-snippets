import { Component, OnInit } from '@angular/core';
import { ImagepostService } from '../services/imagepost.service';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-listing',
  templateUrl: './listing.component.html',
  styleUrls: ['./listing.component.css']
})
export class ListingComponent implements OnInit {

  listItems: any = null;
  constructor(private listService: ImagepostService) { }

  ngOnInit() {
    this.getListings();
  }

  getListings() {
    this.listService.getAll().subscribe( res => {
      this.listItems = res['data'];
      console.log(this.listItems);
    })
  }

  listDel(id, index) {
    this.listItems.splice(index, 1);
    this.listService.delete(id).subscribe( res => {
      alert(res['data']);
    })
  }
}
