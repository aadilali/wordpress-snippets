import { TestBed } from '@angular/core/testing';

import { ImagepostService } from './imagepost.service';

describe('ImagepostService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ImagepostService = TestBed.get(ImagepostService);
    expect(service).toBeTruthy();
  });
});
