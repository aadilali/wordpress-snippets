import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ImagepostService {

  private URL = 'http://127.0.0.1:8000/api/events';
    constructor(private http: HttpClient) { }

    getAll() {
        return this.http.get('http://localhost:8000/api/events');
    }

    getById(id: number) {
        return this.http.get(this.URL+'/'+id);
    }

    imagePost(imageData) {
       let options = { headers: new HttpHeaders().set('Content-Type', 'application/json') };
       return this.http.post('http://localhost:8000/api/events', imageData);
    }

    delete(id: number) {
        return this.http.delete('http://localhost:8000/api/events/'+id);
    }
}
